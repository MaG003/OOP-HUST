package hust.soict.hedspi.test.disc;

public class TestPassingParameter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
