package hust.soict.hedspi.test.book;

public class BookTest {

	public static void main(String[] args) {
		
	}
}