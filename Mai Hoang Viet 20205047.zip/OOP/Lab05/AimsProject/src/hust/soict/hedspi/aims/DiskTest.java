package hust.soict.hedspi.aims;

public class DiskTest {

	public static void main(String[] args) {

	}
}