package hust.soict.dsai.aims.media;
import java.util.ArrayList;
import java.util.List;
public class CompactDisc extends Disc implements Playable
{
	List<Track> tracks = new ArrayList<Track>();

    public CompactDisc(String title, String category, String director, String artist, float cost) {
        super(title, category, cost, director);
    }
    
    public CompactDisc(String title, String category, float cost, String director) {
        super(title, category, cost, director);
    }

    public CompactDisc(String title, String category, float cost) {
        super(title, category, cost);
    }
    
	public void addTrack(Track addtrack) {
		if(tracks.contains(addtrack) == false) {
			tracks.add(addtrack);
			System.out.println("The track has been added");
		}
		
		else System.out.println("The track is already in the list ");
	}
	
	public void removeTrack(Track addtrack) {
		if(tracks.contains(addtrack) == true) {
			tracks.remove(addtrack);
			System.out.println("The track has been added");
		}
		
		else System.out.println("The track is already in the list ");
	}
	
	public int getLenght() {
		int sum = 0;
		for(int i = 0; i < tracks.size();i++) {
			sum +=  tracks.get(i).getLength();
		}
		return sum;
	}
	
	public void play() {
		for(int i = 0; i < tracks.size();i++) {
			tracks.get(i).play();
		}
	}
}