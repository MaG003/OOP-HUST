package hust.soict.dsai.aims.media;

import java.lang.String;
public class DigitalVideoDisc extends  Disc implements Playable{
	
	   public DigitalVideoDisc(String title) {
	        super(title);
	    }

	    public DigitalVideoDisc(String title, String category, float cost) {
	        super(title, category, cost);
	    }

	    public DigitalVideoDisc(String title, String category, String director, int length, float cost) {
	        super(title, category, cost, director, length);
	    }
	
	@Override
	public String toString() {
		return "DVD - " + "[id = " + getId() + getTitle() + " - " + getCategory() + " - " + getDirectory() + " - "
				+ getLength() + ": " + getCost() + "$";
	}
	
	public boolean isMatchTitle(String title1) {
		return this.getTitle().equals(title1);
	}
	
	@Override
	public void play() {
		System.out.println("Playing DVD: " + this.getTitle());
		System.out.println("DVD length: " + this.getLength());
	}

	
}